import boto3
import os
import azure.functions as func
import logging
from botocore.exceptions import ClientError
from typing import List, Dict, Any
import azure.identity
from datetime import datetime

# Configure logging once at startup
logging.basicConfig(
    level=logging.INFO,  # or logging.DEBUG for more detail
    format="%(asctime)s %(levelname)s %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)

def get_aws_s3_client():
    """Exchanges Azure Managed Identity token for AWS temporary credentials."""
    logger.info("🔗 OIDC Bridge: Starting AWS credential exchange")
    
    client_id = os.environ.get("AZURE_CLIENT_ID")
    role_arn = os.environ.get("AWS_ROLE_ARN")
    
    if not client_id or not role_arn:
        logger.error(f"❌ Env missing - ClientID: {bool(client_id)}, RoleARN: {bool(role_arn)}")
        raise ValueError("Missing environment variables")

    try:
        logger.info(f"🆔 Using ManagedIdentityCredential for Client: {client_id}")
        azure_cred = azure.identity.ManagedIdentityCredential(client_id=client_id)
        
        # Define multiple scopes to try (fallbacks for audience compatibility)
        scopes_to_try = [
            "api://sts.amazonaws.com",      # Matches your OIDC aud condition
            "https://sts.amazonaws.com",    # Full URI variant
            "sts.amazonaws.com"             # Bare domain variant
        ]
        
        azure_token = None
        for scope in scopes_to_try:
            try:
                logger.info(f"🔑 Attempting token request for scope: {scope} (Attempt: {scopes_to_try.index(scope) + 1}/{len(scopes_to_try)})")
                azure_token = azure_cred.get_token(scope)
                logger.info(f"✅ Token acquired successfully for scope: {scope}")
                break  # Success, exit loop
            except azure.identity.AuthenticationError as auth_err:
                logger.error(f"❌ AuthenticationError for scope '{scope}': {str(auth_err)}", exc_info=True)
                logger.debug(f"Full stack trace for AuthenticationError: {auth_err.__traceback__}")
            except azure.identity.CredentialUnavailableError as cu_err:
                logger.error(f"❌ CredentialUnavailableError for scope '{scope}': {str(cu_err)}", exc_info=True)
                logger.debug(f"Full stack trace for CredentialUnavailableError: {cu_err.__traceback__}")
            except Exception as e:
                logger.error(f"❌ Unexpected error for scope '{scope}': {str(e)}", exc_info=True)
                logger.debug(f"Full stack trace for unexpected error: {e.__traceback__}")
        
        if azure_token is None:
            raise ValueError("Failed to acquire Azure token after trying all scopes")
        
        logger.info("🤝 Exchanging for AWS STS credentials...")
        sts_client = boto3.client('sts', region_name='us-east-1')
        
        assumed_role = sts_client.assume_role_with_web_identity(
            RoleArn=role_arn,
            RoleSessionName=f"AzureFuncS3-{datetime.utcnow().strftime('%H%M%S')}",
            WebIdentityToken=azure_token.token
        )

        creds = assumed_role['Credentials']
        return boto3.client(
            's3',
            aws_access_key_id=creds['AccessKeyId'],
            aws_secret_access_key=creds['SecretAccessKey'],
            aws_session_token=creds['SessionToken']
        )
        
    except Exception as e:
        logger.error(f"💥 OIDC Fatal: {str(e)}", exc_info=True)
        raise
        
def safe_aws_call(s3_client, func_name: str, key: str, default: Any, **kwargs) -> Any:
    """Error handling wrapper for S3 API calls."""
    logger.info(f"📞 S3.{func_name}({kwargs})")
    try:
        func_call = getattr(s3_client, func_name)
        response = func_call(**kwargs)
        return response.get(key, default)
    except ClientError as e:
        logger.warning(f"⚠️ S3.{func_name} failed [{e.response['Error']['Code']}]")
        return default
    except Exception as e:
        logger.warning(f"⚠️ S3.{func_name}: {str(e)}", exc_info=True)
        return default

def get_s3_buckets_with_metadata() -> List[Dict[str, Any]]:
    """Lists all S3 buckets via OIDC Bridge."""
    logger.info("📦 get_s3_buckets_with_metadata START")
    
    s3_client = get_aws_s3_client()
    
    logger.info("🏠 Listing buckets...")
    response = s3_client.list_buckets()
    buckets = response.get('Buckets', [])
    logger.info(f"✅ Found {len(buckets)} buckets")
    
    bucket_metadata = []
    for i, bucket in enumerate(buckets, 1):
        name = bucket['Name']
        logger.info(f"📍 [{i}/{len(buckets)}] Processing: {name}")
        
        region = safe_aws_call(
            s3_client, 'get_bucket_location', 'LocationConstraint', 
            'us-east-1', Bucket=name
        ) or 'us-east-1'
        
        bucket_metadata.append({
            'name': name,
            'created': bucket['CreationDate'].isoformat(),
            'region': region
        })
    
    logger.info(f"🎉 Returning {len(bucket_metadata)} buckets")
    return bucket_metadata

def get_s3_bucket_details(bucket_name: str) -> Dict[str, Any]:
    """Get detailed info for specific S3 bucket."""
    logger.info(f"📋 get_s3_bucket_details: {bucket_name}")
    s3_client = get_aws_s3_client()
    
    # Basic bucket info
    location = safe_aws_call(s3_client, 'get_bucket_location', 'LocationConstraint', 
                           'us-east-1', Bucket=bucket_name)
    
    # Bucket policy (if exists)
    policy = safe_aws_call(s3_client, 'get_bucket_policy', 'Policy', None, 
                          Bucket=bucket_name)
    
    return {
        'name': bucket_name,
        'region': location or 'us-east-1',
        'policy_exists': policy is not None
    }