import azure.functions as func
import os
import json
import logging
from datetime import datetime

# Configure logging once at startup
logging.basicConfig(
    level=logging.INFO,  # or logging.DEBUG if you want more detail
    format="%(asctime)s %(levelname)s %(name)s: %(message)s"
)

# Use a module-specific logger
logger = logging.getLogger(__name__)

app = func.FunctionApp()

@app.route(route="aws/list", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def list_aws(req: func.HttpRequest) -> func.HttpResponse:
    logger.info("🚀 list_aws START")
    try:
        logger.info("📥 Importing AWS methods...")
        from methods.aws import get_s3_buckets_with_metadata
        logger.info("✅ AWS import success")

        logger.info("🔄 Calling get_s3_buckets_with_metadata...")
        data = get_s3_buckets_with_metadata()
        logger.info(f"✅ SUCCESS: {len(data)} buckets")

        return func.HttpResponse(
            json.dumps(data, default=str),
            mimetype="application/json",
            status_code=200
        )
    except ImportError as e:
        logger.error(f"💥 IMPORT FAILED: {str(e)}", exc_info=True)
        return func.HttpResponse(
            json.dumps({"error": "Import error - check logs"}),
            status_code=500,
            mimetype="application/json"
        )
    except Exception as e:
        logger.error(f"💥 RUNTIME ERROR: {str(e)}", exc_info=True)
        return func.HttpResponse(
            json.dumps({"error": str(e), "timestamp": datetime.utcnow().isoformat()}),
            status_code=500,
            mimetype="application/json"
        )

@app.route(route="azure/list", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def list_azure(req: func.HttpRequest) -> func.HttpResponse:
    logger.info("🚀 list_azure START")
    try:
        sub_id = os.environ.get('AZURE_SUBSCRIPTION_ID')
        logger.info(f"Sub ID: {'✅' if sub_id else '❌'}")

        if not sub_id:
            logger.error("❌ AZURE_SUBSCRIPTION_ID missing")
            return func.HttpResponse("Subscription ID required", status_code=500)

        from methods.azure import get_azure_storage_accounts_with_metadata
        data = get_azure_storage_accounts_with_metadata(sub_id)
        logger.info(f"✅ Azure accounts: {len(data)}")

        return func.HttpResponse(
            json.dumps(data, default=str),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        logger.error(f"💥 Azure list failed: {str(e)}", exc_info=True)
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=500,
            mimetype="application/json"
        )

@app.route(route="aws/details", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def aws_details(req: func.HttpRequest) -> func.HttpResponse:
    logger.info("🚀 aws_details START")
    bucket_name = req.params.get('bucket_name')
    logger.info(f"Bucket: {bucket_name}")

    if not bucket_name:
        logger.warning("❌ Missing bucket_name parameter")
        return func.HttpResponse("bucket_name required", status_code=400)

    try:
        from methods.aws import get_s3_bucket_details
        data = get_s3_bucket_details(bucket_name)
        return func.HttpResponse(
            json.dumps(data, default=str),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        logger.error(f"💥 Bucket details failed: {bucket_name} - {str(e)}", exc_info=True)
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=500,
            mimetype="application/json"
        )

@app.route(route="azure/details", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def azure_details(req: func.HttpRequest) -> func.HttpResponse:
    logger.info("🚀 azure_details START")
    try:
        sub_id = os.environ.get('AZURE_SUBSCRIPTION_ID')
        resource_group = req.params.get('resource_group')
        account_name = req.params.get('account_name')

        logger.info(f"Params: sub={sub_id[:8] if sub_id else '❌'}, rg={resource_group}, acc={account_name}")

        if not all([sub_id, resource_group, account_name]):
            logger.warning("❌ Missing params")
            return func.HttpResponse("Missing: subscription_id, resource_group, account_name", status_code=400)

        from methods.azure import get_azure_storage_details
        data = get_azure_storage_details(sub_id, resource_group, account_name)

        return func.HttpResponse(
            json.dumps(data, default=str),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        logger.error(f"💥 Azure details failed: {str(e)}", exc_info=True)
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=500,
            mimetype="application/json"
        )

logger.info("✅ Functions loaded")
